<template>
  <div id="app">
    <h1>Calculatrice fonctionnelle</h1>
    <CalculatorComponent />
    <p v-if="erreur">{{ erreur }}</p>
  </div>
</template>

<script>
import CalculatorComponent from "./components/Calculator.vue";

export default {
  components: {
    CalculatorComponent
  },
  data() {
    return {
      erreur: ""
    };
  }
};
</script>
