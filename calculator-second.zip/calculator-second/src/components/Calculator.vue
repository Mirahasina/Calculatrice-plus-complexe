<template>
    <div class="calculatrice">
      <input type="text" v-model="expression" @keyup.enter="calculerResultat">
      <button @click="ajouterParenthese('(')">(</button>
      <button @click="ajouterFonction('ln')">ln</button>
      <button @click="ajouterFonction('expo')">expo</button>
      <button @click="ajouterOperateur('^')">^</button>
      <button @click="ajouterParenthese(')')">)</button>
      <button @click="ajouterChiffre(7)">7</button>
      <button @click="ajouterChiffre(8)">8</button>
      <button @click="ajouterChiffre(9)">9</button>
      <button @click="ajouterOperateur('/')">/</button>
      <button @click="ajouterChiffre(4)">4</button>
      <button @click="ajouterChiffre(5)">5</button>
      <button @click="ajouterChiffre(6)">6</button>
      <button @click="ajouterOperateur('*')">*</button>
      <button @click="ajouterChiffre(1)">1</button>
      <button @click="ajouterChiffre(2)">2</button>
      <button @click="ajouterChiffre(3)">3</button>
      <button @click="ajouterOperateur('-')">-</button>
      <button @click="ajouterChiffre(0)">0</button>
      <button @click="ajouterOperateur('+')">+</button>
      <button @click="calculerResultat">=</button>
      <button @click="effacer">Del</button>
    </div>
  </template>
  
  <script>
    // Définition des fonctions pour les opérations plus avancées
    function calculerLogarithmeNaturel(a) {
      if (a <= 0) {
        throw new Error("Erreur : le logarithme naturel de 0 ou d'un nombre négatif n'est pas défini");
      }
      return Math.log(a);
    }
  
    function calculerExponentielle(x) {
      return Math.pow(Math.E, x);
    }
  
    // Définition de la fonction pour évaluer une expression mathématique
    function evaluerExpression(expression) {
      try {
        // Remplacer les fonctions Math.exp et Math.log par leurs équivalents en notation exponentielle
        expression = expression.replace(/Math\.exp\(/g, 'Math.E^(');
        expression = expression.replace(/Math\.log\(/g, 'Math.log(');
  
        // Évaluation de l'expression à l'aide de la fonction Function de JavaScript
        const resultat = new Function('return ' + expression)();
  
        // Vérifier si le résultat est un nombre fini
        if (isFinite(resultat)) {
          return resultat;
        } else {
          throw new Error('Erreur : le résultat de l\'expression n\'est pas un nombre fini');
        }
      } catch (erreur) {
        // Affichage d'un message d'erreur en cas d'échec de l'évaluation de l'expression
        console.error(erreur.message);
        return null;
      }
    }
  
    export default {
      data() {
        return {
          expression: "",
          erreur: "",
          parenCount: 0 // Ajouter cette ligne
        };
      },
      methods: {
        calculerResultat() {
          const resultat = evaluerExpression(this.expression);
          if (resultat !== null) {
            this.expression = resultat;
          } else {
            this.erreur = "Erreur : expression invalide";
          }
        },
        effacer() {
          this.expression = "";
          this.erreur = "";
        },
        ajouterChiffre(chiffre) {
          this.expression += chiffre;
          this.erreur = "";
        },
        ajouterOperateur(operateur) {
          this.expression += operateur;
          this.erreur = "";
        },
        ajouterFonction(fonction) {
          if (fonction === 'ln') {
            // Ajouter la fonction logarithme naturel à l'expression
            this.expression += 'Math.log(';
          } else if (fonction === 'expo') {
            // Ajouter la fonction exponentielle à l'expression
            this.expression += 'Math.E^(';
          } else if (fonction === '^') {
            // Ajouter l'opérateur de puissance à l'expression
            this.expression += '**';
          } else if (fonction === '(') {
            // Ajouter une parenthèse ouvrante à l'expression
            this.expression += '(';
            this.parenCount++;
          } else if (fonction === ')') {
            // Ajouter une parenthèse fermante à l'expression
            if (this.parenCount > 0) {
              this.expression += ')';
              this.parenCount--;
            }
          }
          this.erreur = "";
        },
        ajouterParenthese(parenthese) {
          if (parenthese === "(" && this.expression.slice(-1) === "(") {
            this.erreur = "Erreur : trop de parenthèses ouvertes";
          } else if (parenthese === ")" && this.expression.slice(-1) === ")") {
            this.erreur = "Erreur : trop de parenthèses fermées";
          } else {
            this.expression += parenthese;
            this.erreur = "";
          }
        }
      }
    };
  </script>
  
  <style src="./../../public/css/output.css"></style>
  